from main import *
from python_initials import *
from linearization import *
from identify_bayer_pattern import *

def white_world_balance(img):
    
# Finding maximum values for each color in the Bayer pattern
    max_red = np.max(img[0::2, 0::2])  # Red pixels
    max_green = max([np.max(img[0::2, 1::2]), np.max(img[1::2, 0::2])])  # Green pixels
    max_blue = np.max(img[1::2, 1::2])  # Blue pixels
    
    # Apply scaling
    img[0::2,0::2] /= max_red
    img[0::2,1::2] /= max_green
    img[1::2,0::2] /= max_green
    img[1::2,1::2] /= max_blue
    
    return img

def gray_world_balance(img):

# Flatten image before applying changes
    flat_img = img.flatten()
    
# Compute the average value for each color channel
    avg_red = np.mean(img[0::2, 0::2])  # Average red
    avg_green = np.mean(np.array([np.mean(img[0::2, 1::2]), np.mean(img[1::2, 0::2])]))  # Average green
    avg_blue = np.mean(img[1::2, 1::2])  # Average blue
    
# Calculate the overall average across all channels
    average_color = (avg_red + avg_green + avg_blue) / 3
    
# Adjust each channel towards the overall average to maintain color neutrality
    img[0::2, 0::2] *= (average_color / avg_red)
    img[0::2, 1::2] *= (average_color / avg_green)
    img[1::2, 0::2] *= (average_color / avg_green)
    img[1::2, 1::2] *= (average_color / avg_blue)
    
    return img

# Set scales for manual white balancing
red_scale, green_scale, blue_scale = 1.628906, 1.000000, 1.386719

def white_balance_preset(img, red_scale, green_scale, blue_scale):

# Apply the scale factors
    img[0::2,0::2] *= red_scale
    img[0::2,1::2] *= green_scale
    img[1::2,0::2] *= green_scale
    img[1::2,1::2] *= blue_scale
    
    return img

# Process the image through different white balance methods
white_balanced_img = white_world_balance(linearized)
gray_balanced_img = gray_world_balance(linearized)
balanced_img = white_balance_preset(linearized, red_scale, green_scale, blue_scale)

# Display the processed images
# display_img(np.clip(white_balanced_img * 1, 0, 1))
# display_img(np.clip(gray_balanced_img * 1, 0, 1))
# display_img(np.clip(balanced_img * 1, 0, 1))