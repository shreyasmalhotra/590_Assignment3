from main import *
from python_initials import *
from linearization import *

# Display top left 2x2 pixels for color pattern
top_left_2x2 = linearized[:2, :2]
# display_img(top_left_2x2)