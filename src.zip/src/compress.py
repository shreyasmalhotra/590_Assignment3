from python_initials import *
from linearization import *
from white_balancing import *
from identify_bayer_pattern import *
from white_balancing import *
from demosaicing import *
from color_space_correction import *
from brightness_gamma import *

def save_and_calculate_compression(processed_imgs, target_quality=95):
    # For simplicity, let's use the brightened and gamma-adjusted img
    brightened_img = processed_imgs[0.5][2]  # Assuming index 2 is for the gray world image

    # Save the image in PNG format (lossless, original quality).
    png_filename = 'img_final.png'
    imsave(png_filename, img_as_ubyte(brightened_img))

    # Calculate the file size of the PNG image.
    png_size = os.path.getsize(png_filename)

    # Save the image in JPEG format at the specified quality level for initial comparison.
    jpeg_filename = f'img_final{target_quality}.jpg'
    imsave(jpeg_filename, img_as_ubyte(brightened_img), quality=target_quality)
    jpeg_size = os.path.getsize(jpeg_filename)

    # Calculate the compression ratio.
    compression_ratio = png_size / jpeg_size
    print(f"Compression ratio (quality={target_quality}) for Final Image: {compression_ratio:.2f}")

    # Iterate through a range of quality settings to find the lowest acceptable quality that is visually indistinguishable.
    for quality in range(target_quality, 0, -5):
        jpeg_filename_quality = f'img_final{quality}.jpg'
        imsave(jpeg_filename_quality, img_as_ubyte(brightened_img), quality=quality)
        jpeg_size_quality = os.path.getsize(jpeg_filename_quality)
        compression_ratio_quality = png_size / jpeg_size_quality

        print(f"Compression ratio (quality={quality}) for Final Image: {compression_ratio_quality:.2f}")

        if compression_ratio_quality > 10:
            print(f"Stopping at quality={quality} with compression ratio greater than 10.")
            break

# Example usage of the function.
save_and_calculate_compression(processed_imgs)