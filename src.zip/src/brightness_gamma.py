from python_initials import *
from linearization import *
from white_balancing import *
from identify_bayer_pattern import *
from white_balancing import *
from demosaicing import *
from color_space_correction import *

def adjust_brightness_and_apply_gamma(img_sRGB, target_brightness=0.5):
    # Calculate the scale factor to adjust the img brightness to the target mean value
    current_mean = rgb2gray(img_sRGB).mean()  # Calculate the mean brightness of the grayscale version of the img
    brightness_scale_factor = target_brightness / current_mean
    brightened_img = brightness_scale_factor * img_sRGB  # Scale the img brightness
    brightened_img = np.clip(brightened_img, 0, 1)  # Clip the pixel values to ensure they are between 0 and 1

    # Apply gamma encoding to enhance visibility on displays
    gamma_threshold = 0.0031308  # Threshold for linear vs. nonlinear gamma correction region
    linear_region = brightened_img < gamma_threshold
    nonlinear_region = ~linear_region
    
    # Linear scaling for values below the threshold
    brightened_img[linear_region] *= 12.92
    
    # Nonlinear scaling for values above the threshold
    brightened_img[nonlinear_region] = (1 + 0.055) * (brightened_img[nonlinear_region] ** (1 / 2.4)) - 0.055

    return brightened_img

# Set different target brightness values to demonstrate the effect of different adjustments.
brightness_levels = [0.25, 0.5, 0.75, 0.95]

# Process imgs through brightness adjustment and gamma encoding for each specified brightness level.
imgs = [img_sRGB, img_sRGB_whiteworld, img_sRGB_grayworld, img_sRGB_camerapreset]
processed_imgs = {brightness: [adjust_brightness_and_apply_gamma(img, brightness) for img in imgs] for brightness in brightness_levels}

# Display the processed imgs for each brightness level.
for brightness, imgs in processed_imgs.items():
    for img in imgs:
        display_img(np.clip(img * 1, 0, 1), color=True)

# Display imgs with increasing brightness levels to visually compare the effect.
for brightness in brightness_levels:
    display_img(np.clip(adjust_brightness_and_apply_gamma(img_sRGB_camerapreset, brightness) * 1, 0, 1), color=True)
