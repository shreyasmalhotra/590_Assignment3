from main import *
from python_initials import *

# Defining color limits for normalization
black, white = 0, 16383

# Normalizing and clipping the image data to keep its values between 0 and 1
normalized = np.clip((img_double - black) / (white - black), 0, 1)
linearized = np.clip(normalized, 0, 1)

# Function to display an image
def display_img(img, color=False):
    plt.figure(figsize=(12, 9))
    plt.imshow(img, cmap=None if color else 'gray')
    plt.colorbar()
    plt.show()

# Displaying the image after linear transformation
# display_img(np.clip(img_double * 1, 0, 16383))
# display_img(np.clip(linearized * 1, 0, 1))
