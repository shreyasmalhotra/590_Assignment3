# Dependencies
from main import *

# CODE
# Set the file path for the image. Interpret the string as raw for file path
img_path = r'C:\Users\shrey\OneDrive\Desktop\590_Assignment3\data\baby.tiff'

# Read the image from the file path into an array
img = imread(img_path)

# Check the number of dimensions in the image array
if img.ndim == 2:
    # If the image is grayscale, it will only have two dimensions
    height, width = img.shape
elif img.ndim == 3:
    # If the image is in color, it will have three dimensions (color channels is 3rd dimension)
    height, width, _ = img.shape

# Calculate num bits per pixel, 'dtype.itemsize' gives the size of the data type in bytes
num_bits = img.dtype.itemsize * 8

# Convert the image data to a double precision floating point format
img_double = img.astype(np.float64)
