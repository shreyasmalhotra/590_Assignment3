import numpy as np
import os
import rawpy
import matplotlib
import matplotlib.patches as patches
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
from skimage.io import imread, imsave
from skimage.color import rgb2gray
from skimage import img_as_ubyte