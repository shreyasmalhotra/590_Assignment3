from python_initials import *
from linearization import *
from white_balancing import *
from identify_bayer_pattern import *
from white_balancing import *
from demosaicing import *

def adjust_color_space(img):

# Define the transformation matrix from sRGB to XYZ color space
    matrix_sRGB_to_XYZ = np.array([
        [0.4124564, 0.3575761, 0.1804375],
        [0.2126729, 0.7151522, 0.0721750],
        [0.0193339, 0.1191920, 0.9503041]
    ])

# Define the transformation matrix from camera color space to XYZ
    matrix_XYZ_to_cam = np.array([
        6988,-1384,-714,-5631,13410,2447,-1485,2204,7318
    ]).reshape((3, 3))

# Compute the transformation matrix from camera RGB to sRGB by combining the two matrices above
    matrix_sRGB_to_camera =  matrix_XYZ_to_cam @ matrix_sRGB_to_XYZ

# Normalize the transformation matrix so that the rows sum to 1
    matrix_sRGB_to_camera_normalized = matrix_sRGB_to_camera / np.sum(matrix_sRGB_to_camera, axis=1)

# Calculate the inverse of the normalized transformation matrix.
    matrix_sRGB_to_camera_inv = np.linalg.inv(matrix_sRGB_to_camera_normalized)

# Flatten the image to apply the color space transformation to each pixel
    flattened_img = img.reshape(-1, 3)

# Apply the transformation matrix to convert each pixel to the sRGB color space
    transformed_pixels = flattened_img @ matrix_sRGB_to_camera_inv.T

# Reshape the transformed pixels back to the original image shape
    transformed_img = transformed_pixels.reshape(img.shape)
        
# Clip the pixel values to the range [0, 1] to maintain valid image data
    final_img = np.clip(transformed_img, 0, 1)

    return final_img

img_sRGB = adjust_color_space(demosaiced_linearized_img)
img_sRGB_whiteworld = adjust_color_space(demosaiced_whiteworld_img)
img_sRGB_grayworld = adjust_color_space(demosaiced_grayworld_img)
img_sRGB_camerapreset = adjust_color_space(demosaiced_camerapreset_img)

# display_img(np.clip(img_sRGB*1, 0, 1),color=True)
# display_img(np.clip(img_sRGB_whiteworld*1, 0, 1),color=True)
# display_img(np.clip(img_sRGB_grayworld*1, 0, 1),color=True)
# display_img(np.clip(img_sRGB_camerapreset*1, 0, 1),color=True)