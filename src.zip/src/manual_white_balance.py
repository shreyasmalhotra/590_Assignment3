import matplotlib
matplotlib.use('TkAgg')  # This line configures matplotlib to use the TkAgg backend, which allows for interactive plotting in some environments.

# Import various modules needed for image processing.
from python_initials import *
from linearization import *
from white_balancing import *
from identify_bayer_pattern import *
from demosaicing import *
from color_space_correction import *
from brightness_gamma import *
from compress import *
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

def adjust_white_balance_using_patch(sample_image, selected_area):
    """
    Adjusts the white balance of an image by calculating color gains from a user-selected patch.
    `selected_area` is a tuple with coordinates (ymin, ymax, xmin, xmax) defining a rectangular area in the image.
    """
    if not selected_area:
        print("Invalid area coordinates provided. Please try again.")
        return None

    ymin, ymax, xmin, xmax = selected_area

    # Extract the red, green, and blue pixel values from the image using the Bayer pattern RGGB.
    red_pixels = sample_image[ymin:ymax:2, xmin:xmax:2]
    green_pixels_row = sample_image[ymin:ymax:2, xmin+1:xmax:2]
    green_pixels_col = sample_image[ymin+1:ymax:2, xmin:xmax:2]
    blue_pixels = sample_image[ymin+1:ymax:2, xmin+1:xmax:2]

    # Compute the average color intensity for each set of colored pixels in the selected patch.
    red_average = np.mean(red_pixels)
    green_average = (np.mean(green_pixels_row) + np.mean(green_pixels_col)) / 2
    blue_average = np.mean(blue_pixels)

    # Calculate the correction factors needed to balance the colors.
    red_gain = green_average / red_average if red_average != 0 else 1
    blue_gain = green_average / blue_average if blue_average != 0 else 1

    # Apply these correction factors across the whole image to balance the colors.
    white_balanced_image = np.copy(sample_image)
    white_balanced_image[0::2, 0::2] *= red_gain  # Apply red gain to red pixels
    white_balanced_image[1::2, 1::2] *= blue_gain  # Apply blue gain to blue pixels

    return white_balanced_image


def prompt_for_white_patch(image_to_patch):
    plt.figure(figsize=(10, 6))
    plt.imshow(np.clip(image_to_patch * 5, 0, 1), cmap='gray' if image_to_patch.ndim == 2 else None)
    plt.title('Click on the image and select white patch')
    selected_points = plt.ginput(2)  # Allows the user to pick two points on the plot.
    plt.close()

    if len(selected_points) < 2:
        print("Insufficient points selected. Please select exactly two points.")
        return None

    ymin, ymax = sorted([int(selected_points[0][1]), int(selected_points[1][1])])
    xmin, xmax = sorted([int(selected_points[0][0]), int(selected_points[1][0])])
    rect = patches.Rectangle((xmin, ymin), xmax - xmin, ymax - ymin, linewidth=1, edgecolor='r', facecolor='none')

    plt.figure(figsize=(10, 6))
    plt.imshow(np.clip(image_to_patch, 0, 1))
    plt.colorbar()
    plt.gca().add_patch(rect)
    plt.title("Image with Selected White Patch")
    plt.show()
    return ymin, ymax, xmin, xmax

# Assuming 'linearized' contains the image data prepared earlier.
selected_patch_coordinates = prompt_for_white_patch(linearized)
if selected_patch_coordinates:
    white_balanced_image = adjust_white_balance_using_patch(linearized, selected_patch_coordinates)
    demosaiced_image = demosaicing_CFA_Bayer_bilinear(white_balanced_image, 'RGGB')
    corrected_color_image = adjust_color_space(demosaiced_image)
    final_adjusted_image = adjust_brightness_and_apply_gamma(corrected_color_image, target_brightness=0.5)
    display_img(final_adjusted_image, color=True)
else:
    print("No patch coordinates selected. Exiting.")
