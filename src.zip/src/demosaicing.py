from python_initials import *
from linearization import *
from white_balancing import *
from identify_bayer_pattern import *
from white_balancing import *
from colour_demosaicing import demosaicing_CFA_Bayer_bilinear

# LINEARIZED IMAGE
# Demosaic the linearized image using a specific Bayer pattern (RGGB)
demosaiced_linearized_img = demosaicing_CFA_Bayer_bilinear(linearized, 'RGGB')
# Display the demosaiced image. The 'np.clip' function ensures pixel values are between 0 and 1
# Multiplying by 1 due to high brightness and overexposure.
# display_img(np.clip(demosaiced_linearized_img*1, 0, 1))
# Display the same image but with color processing enabled to show the true color image
# display_img(np.clip(demosaiced_linearized_img*1, 0, 1),color=True)

# WHITE WORLD BALANCE
# Demosaic the white-balanced image using the same RGGB Bayer pattern
demosaiced_whiteworld_img = demosaicing_CFA_Bayer_bilinear(white_balanced_img, 'RGGB')
# Display the white-balanced and demosaiced image in color
# display_img(np.clip(demosaiced_whiteworld_img*1, 0, 1),color=True)

# GRAY WORLD BALANCE
# Demosaic the gray-world balanced image
demosaiced_grayworld_img = demosaicing_CFA_Bayer_bilinear(gray_balanced_img, 'RGGB')
# Display the gray-world balanced and demosaiced image in color
# display_img(np.clip(demosaiced_grayworld_img*1, 0, 1),color=True)

# CAMERA PRESET BALANCE
# Demosaic the camera-preset balanced image
demosaiced_camerapreset_img = demosaicing_CFA_Bayer_bilinear(balanced_img, 'RGGB')
# Display the camera-preset balanced and demosaiced image in color
# display_img(np.clip(demosaiced_camerapreset_img*1, 0, 1),color=True)
